import React from "react";
import "./Header.css";
const Header = () => {
  return (
    <div>
      <header>
        <p className="logo">
          <a href="#abcd#">
            Aca<span style={{ color: "#3FB04B" }}>S</span>ync
          </a>
        </p>
        <p className="items">Documents</p>
        <p className="items">Attendance</p>
        <p className="items">Profile</p>
        <p className="items">Search</p>
        <p className="items">Home</p>
      </header>
    </div>
  );
};

export default Header;
