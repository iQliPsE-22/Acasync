import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./components/Login";
import Admin from "./components/Admin";
import StudentSign from "./components/StudentSign";
import AdminSign from "./components/AdminSign";
import Dashboard from "./components/Dashboard";
import StudentList from "./components/StudentList";
import Landing from './components/Landing';

function App() {

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
            <Route path = "/" element = {<Landing/>}/>
          <Route path="/student-login" element={<Login />} />
          <Route path="/admin-login" element={<Admin />} />
          <Route path="/student-signup" element={<StudentSign />} />
          <Route path="/admin-signup" element={<AdminSign />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/list" element={<StudentList />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
